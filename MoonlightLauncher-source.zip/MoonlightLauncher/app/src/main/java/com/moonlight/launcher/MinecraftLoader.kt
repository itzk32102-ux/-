package com.moonlight.launcher

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.AssetManager
import android.os.Build
import dalvik.system.PathClassLoader
import org.lsposed.hiddenapibypass.HiddenApiBypass

/**
 * Runs the INSTALLED Minecraft Bedrock inside Moonlight's own process.
 * Needs the real Minecraft app installed (it never bundles or copies the game).
 * UNTESTED against 26.51: expect to adjust this file when Mojang changes things.
 */
object MinecraftLoader {
    const val PKG = "com.mojang.minecraftpe"
    private var ready = false
    @Volatile private var cached: PathClassLoader? = null

    private fun buildLoader(ai: android.content.pm.ApplicationInfo): PathClassLoader {
        val apks = listOf(ai.sourceDir) + (ai.splitSourceDirs?.toList() ?: emptyList())
        val libs = (apks.map { "$it!/lib/arm64-v8a" } + ai.nativeLibraryDir).joinToString(":")
        return PathClassLoader(apks.joinToString(":"), libs, null)
    }

    /** Runs once when Moonlight opens, so pressing Launch later has less to do. Safe to fail. */
    fun prewarm(app: android.app.Application) {
        if (cached != null || !isInstalled(app)) return
        Thread {
            try {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
                val ai = app.packageManager.getApplicationInfo(PKG, 0)
                val l = buildLoader(ai)
                try { Class.forName("$PKG.MainActivity", false, l) } catch (_: Throwable) {}   // opens + verifies dex
                cached = l
                // read the base APK once so Android keeps it in memory (page cache)
                val buf = ByteArray(1 shl 20)
                java.io.File(ai.sourceDir).inputStream().use { while (it.read(buf) > 0) { } }
            } catch (_: Throwable) {}
        }.start()
    }

    fun isInstalled(c: Context) = try { c.packageManager.getPackageInfo(PKG, 0); true } catch (e: Exception) { false }

    /** Plain, normal Minecraft launch. Always works if Minecraft is installed. */
    fun normal(a: Activity, note: String): String {
        val i = a.packageManager.getLaunchIntentForPackage(PKG) ?: return "Couldn't open Minecraft. Is it installed?"
        a.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return note
    }

    /**
     * Tries Moonlight mode (game inside Moonlight). If that fails or crashed last time,
     * it automatically opens normal Minecraft instead, so Launch never just does nothing.
     */
    fun launch(a: Activity): String? {
        if (!isInstalled(a)) return "Minecraft isn't installed."
        val p = a.getSharedPreferences("moon", Context.MODE_PRIVATE)
        if (p.getBoolean("fallback", false) || Build.SUPPORTED_ABIS.firstOrNull() != "arm64-v8a")
            return normal(a, "Opened normal Minecraft (Moonlight mode crashed last time).")
        try {
            if (!ready) { prepare(a); ready = true }
            p.edit().putBoolean("pending", true).commit()
            a.startActivity(Intent().setClassName(a.packageName, "$PKG.MainActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (t: Throwable) {
            p.edit().putBoolean("pending", false).apply()
            return normal(a, "Moonlight mode failed (${t.javaClass.simpleName}: ${t.message}). Opened normal Minecraft.")
        }
        return null
    }

    private fun prepare(a: Activity) {
        HiddenApiBypass.addHiddenApiExemptions("L")
        val ai = a.packageManager.getApplicationInfo(PKG, 0)
        val apks = listOf(ai.sourceDir) + (ai.splitSourceDirs?.toList() ?: emptyList())
        val mc = cached ?: buildLoader(ai)

        // 1) make our app's class loader able to find Minecraft's classes
        val base = a.applicationContext.let { (it as android.content.ContextWrapper).baseContext }
        val pkgInfo = field(base, "mPackageInfo")
        val original = field(pkgInfo, "mClassLoader") as ClassLoader
        val combined = object : ClassLoader(original) {
            override fun findClass(name: String): Class<*> = mc.loadClass(name)
        }
        setField(pkgInfo, "mClassLoader", combined)

        // 2) let our resources/assets see Minecraft's assets
        for (apk in apks) HiddenApiBypass.invoke(AssetManager::class.java, a.assets, "addAssetPath", apk)
    }

    private fun field(o: Any, n: String): Any {
        var c: Class<*>? = o.javaClass
        while (c != null) { try { return c.getDeclaredField(n).apply { isAccessible = true }.get(o)!! } catch (_: NoSuchFieldException) { c = c.superclass } }
        throw NoSuchFieldException(n)
    }
    private fun setField(o: Any, n: String, v: Any) {
        var c: Class<*>? = o.javaClass
        while (c != null) { try { c.getDeclaredField(n).apply { isAccessible = true }.set(o, v); return } catch (_: NoSuchFieldException) { c = c.superclass } }
        throw NoSuchFieldException(n)
    }
}
