package com.moonlight.launcher

import android.content.Intent
import android.graphics.BitmapFactory
import android.content.ContentValues
import android.net.Uri
import androidx.core.content.ContextCompat
import android.provider.MediaStore
import android.graphics.ImageDecoder
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.AnimatedImageDrawable
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowForward
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.RocketLaunch
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Sidebar layout, wide and landscape-first. Brand: Moonlight. */
class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("moon", MODE_PRIVATE) }
    private var transp by mutableStateOf(10f)   // 0 = solid panels, 100 = fully see-through

    private fun load(): MutableList<Feature> {
        val a = JSONArray(prefs.getString("features", "[]"))
        return MutableList(a.length()) { val o = a.getJSONObject(it); Feature(o.getString("n"), o.getString("c"), o.getBoolean("on")) }
    }
    private fun save(l: List<Feature>) = prefs.edit().putString("features",
        JSONArray(l.map { JSONObject().put("n", it.name).put("c", it.code).put("on", it.on) }).toString()).apply()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
    /** true = fine to launch. Starts the screen-wide "?" button; asks for permission the first time. */
    private fun ensureOverlay(): Boolean {
        if (!prefs.getBoolean("ov_service", true)) return true
        if (!android.provider.Settings.canDrawOverlays(this)) {
            toast("Allow \"Display over other apps\" for Moonlight")
            startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return false
        }
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        return true
    }
    private fun openUrl(u: String) = try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (e: Exception) { toast("No browser found") }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowCompat.getInsetsController(window, window.decorView).hide(WindowInsetsCompat.Type.systemBars())
        transp = prefs.getFloat("transp", 10f)
        setContent { App() }
    }

    @Composable
    private fun App() {
        var page by remember { mutableStateOf("home") }
        var tab by remember { mutableStateOf(0) }
        var accent by remember { mutableStateOf(Color(prefs.getInt("accent", 0xFF6B4EF0.toInt()))) }
        var mode by remember { mutableStateOf(prefs.getString("mode", "dark")!!) }
        var acct by remember { mutableStateOf(prefs.getString("acct", "")!!) }
        var showAcct by remember { mutableStateOf(acct.isEmpty()) }
        val feats = remember { mutableStateListOf<Feature>().apply { addAll(load()) } }
        var bg by remember { mutableStateOf<File?>(File(filesDir, "bg.dat").takeIf { it.exists() }) }
        var bgKey by remember { mutableStateOf(0) }
        var bright by remember { mutableStateOf(prefs.getFloat("bright", 100f)) }
        var blurV by remember { mutableStateOf(prefs.getFloat("blur", 0f)) }
        var msg by remember { mutableStateOf("") }
        var libVersion by remember { mutableStateOf(0) }
        val dark = when (mode) { "light" -> false; "dark" -> true; else -> isSystemInDarkTheme() }
        val surface = if (dark) Color(0xFF0E1024) else Color(0xFFF1F1F8)
        val base = if (dark) Color(0xFF070816) else Color.White
        val scheme = if (dark) darkColorScheme(primary = accent, onPrimary = Color.White, background = base, surface = surface)
                     else lightColorScheme(primary = accent, onPrimary = Color.White, background = base, surface = surface)

        val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) try {
                val f = File(filesDir, "bg.dat")
                contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                bg = f; bgKey++
                transp = 65f; prefs.edit().putFloat("transp", 65f).apply()   // let the picture show through the panels
            } catch (e: Exception) { toast("Couldn't load that picture") }
        }
        val importPick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) try { msg = PackBuilder.importFile(this@MainActivity, uri) ?: "Sent to Minecraft"; libVersion++; toast(msg) }
            catch (e: Exception) { msg = "Import failed: ${e.message}"; toast(msg) }
        }
        val icon = remember { Base64.decode(IconData.B64, Base64.DEFAULT).let { BitmapFactory.decodeByteArray(it, 0, it.size).asImageBitmap() } }
        val launch: () -> Unit = {
            if (!ensureOverlay()) { msg = "Allow \"Display over other apps\" for Moonlight, come back, and press Launch again." }
            else { msg = MinecraftLoader.launch(this@MainActivity) ?: ""; if (msg.isNotEmpty()) toast(msg) }
            Unit
        }

        val cfg = androidx.compose.ui.platform.LocalConfiguration.current
        val dens = androidx.compose.ui.platform.LocalDensity.current
        val ui = (cfg.screenHeightDp / 430f).coerceIn(0.55f, 1f)
        CompositionLocalProvider(androidx.compose.ui.platform.LocalDensity provides androidx.compose.ui.unit.Density(dens.density * ui, dens.fontScale)) {
        MaterialTheme(colorScheme = scheme) {
            Box(Modifier.fillMaxSize().background(base)) {
                bg?.let { BgLayer(it, bgKey, bright, blurV) }
                Row(Modifier.fillMaxSize()) {
                    // ---------------- sidebar ----------------
                    Column(Modifier.width(215.dp).fillMaxHeight().background(surface.copy(alpha = 1f - transp / 100f)).verticalScroll(rememberScrollState()).padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 10.dp)) {
                            Image(icon, null, Modifier.size(44.dp).clip(CircleShape).border(2.dp, accent, CircleShape), contentScale = ContentScale.Crop)
                            Spacer(Modifier.width(10.dp))
                            Column { Text("Moonlight", color = accent, fontSize = 26.sp, fontWeight = FontWeight.Bold); Text("Minecraft Bedrock Edition", fontSize = 11.sp, color = Color.Gray) }
                        }
                        listOf("home" to (Icons.Outlined.Home to "Home"), "inst" to (Icons.Outlined.PlayArrow to "Instances"), "mods" to (Icons.Outlined.Extension to "Mods"), "cosm" to (Icons.Outlined.Palette to "Cosmetics"),
                            "import" to (Icons.Outlined.FileDownload to "Import World / Packs"), "set" to (Icons.Outlined.Settings to "Settings"), "about" to (Icons.Outlined.Info to "About")).forEach { (k, v) ->
                            val sel = page == k
                            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(14.dp))
                                .background(if (sel) accent else Color.Transparent).clickable { page = k }.padding(horizontal = 12.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Icon(v.first, null, Modifier.size(22.dp), tint = if (sel) Color.White else MaterialTheme.colorScheme.onBackground); Spacer(Modifier.width(12.dp))
                                Text(v.second, fontSize = 15.sp, color = if (sel) Color.White else MaterialTheme.colorScheme.onBackground, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("Moonlight 1.0.0", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(8.dp))
                    }
                    // ---------------- main ----------------
                    Column(Modifier.weight(1f).fillMaxHeight().padding(horizontal = 20.dp, vertical = 10.dp)) {
                        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Spacer(Modifier.weight(1f))
                            Row(Modifier.clip(RoundedCornerShape(16.dp)).background(surface.copy(alpha = 1f - transp / 100f)).clickable { showAcct = true }.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Image(icon, null, Modifier.size(46.dp).clip(CircleShape).border(2.dp, Color.White, CircleShape), contentScale = ContentScale.Crop)
                                Spacer(Modifier.width(10.dp))
                                if (acct.isEmpty()) Text("Add account", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(end = 6.dp))
                                else Column(Modifier.padding(end = 8.dp)) {
                                    Text(acct, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                                    Row(verticalAlignment = Alignment.CenterVertically) { Text("Online ", fontSize = 13.sp, color = Color.Gray); Box(Modifier.size(9.dp).clip(CircleShape).background(Color(0xFF22C55E))) }
                                }
                            }
                            IconButton({ toast("No notifications") }) { Icon(Icons.Outlined.Notifications, null) }
                            IconButton({ page = "set" }) { Icon(Icons.Outlined.Settings, null) }
                        }
                        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                            when (page) {
                                "home" -> HomePage(accent, launch, { page = it }, { importPick.launch("*/*") }, libVersion) { f -> msg = PackBuilder.openFile(this@MainActivity, f) ?: "Sent to Minecraft"; toast(msg) }
                                "inst" -> Panel { Text("Instances", fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("Default · Minecraft Bedrock Edition", color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
                                    Button({ toast("More instances soon") }, Modifier.padding(top = 12.dp).height(48.dp)) { Text("Create instance") } }
                                "mods" -> ModsPage(feats, { importPick.launch("*/*") }) { msg = it }
                                "cosm" -> CosmeticsPage(accent)
                                "import" -> Panel {
                                    Text("Import World / Packs", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                    Text("Pick a .mcworld, .mcpack, .mcaddon or .mctemplate file. Minecraft opens and imports it.", color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp))
                                    Button({ importPick.launch("*/*") }, Modifier.height(52.dp)) { Text("Choose file") } }
                                "set" -> SettingsPage(tab, { tab = it }) { PersonalizationPage(accent, { accent = it; prefs.edit().putInt("accent", it.toArgb()).apply() }, mode, { mode = it; prefs.edit().putString("mode", it).apply() },
                                    bg != null, { pick.launch("image/*") }, { bg = null; File(filesDir, "bg.dat").delete() },
                                    bright, { bright = it; prefs.edit().putFloat("bright", it).apply() }, blurV, { blurV = it; prefs.edit().putFloat("blur", it).apply() }) }
                                else -> Panel { Text("Moonlight 1.0.0", fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("A launcher for Minecraft Bedrock Edition.", color = Color.Gray) }
                            }
                            if (msg.isNotEmpty()) Text(msg, color = Color.Gray, modifier = Modifier.padding(top = 12.dp))
                        }
                    }
                }
                if (showAcct) {
                    var t by remember { mutableStateOf(acct) }
                    AlertDialog(onDismissRequest = { showAcct = false },
                        title = { Text(if (acct.isEmpty()) "Add account" else "Account") },
                        text = { Column {
                            Text("Saved on this phone only. This is a display name, not a Microsoft sign-in.", color = Color.Gray, fontSize = 13.sp)
                            OutlinedTextField(t, { t = it }, singleLine = true, label = { Text("Username") }, modifier = Modifier.padding(top = 10.dp)) } },
                        confirmButton = { TextButton({ if (t.isNotBlank()) { acct = t.trim(); prefs.edit().putString("acct", acct).apply() }; showAcct = false }) { Text("Save") } },
                        dismissButton = { Row {
                            if (acct.isNotEmpty()) TextButton({ acct = ""; prefs.edit().putString("acct", "").apply(); showAcct = false }) { Text("Remove") }
                            TextButton({ showAcct = false }) { Text("Later") } } })
                }
            }
        }
        }
    }

    // ---------- background (photo or animated GIF) ----------
    @Composable private fun BgLayer(file: File, key: Int, bright: Float, blurV: Float) {
        AndroidView(factory = { ctx -> ImageView(ctx).apply { scaleType = ImageView.ScaleType.CENTER_CROP } },
            modifier = Modifier.fillMaxSize(),
            update = { iv ->
                if (iv.tag != key) {
                    iv.tag = key
                    try {
                        if (Build.VERSION.SDK_INT >= 28) {
                            val d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(file)) { dec, info, _ ->
                                dec.setTargetSampleSize(maxOf(1, maxOf(info.size.width, info.size.height) / 2000)) }
                            iv.setImageDrawable(d)
                            if (d is AnimatedImageDrawable) { d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE; d.start() }
                        } else iv.setImageBitmap(BitmapFactory.decodeFile(file.path))
                    } catch (e: Exception) { toast("That file isn't a picture or GIF") }
                }
                val f = bright / 100f
                iv.colorFilter = android.graphics.ColorMatrixColorFilter(android.graphics.ColorMatrix().apply { setScale(f, f, f, 1f) })
                if (Build.VERSION.SDK_INT >= 31) {
                    val r = blurV / 5f * iv.resources.displayMetrics.density
                    iv.setRenderEffect(if (r > 0.5f) RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP) else null)
                }
            })
    }

    // ---------- shared bits ----------
    @Composable private fun Panel(mod: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) =
        Card(mod.fillMaxWidth(), shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 1f - transp / 100f))) {
            Column(Modifier.padding(18.dp), content = content) }

    @Composable private fun SwitchRow(title: String, sub: String, value: Boolean, onChange: (Boolean) -> Unit) =
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(title, fontSize = 18.sp, fontWeight = FontWeight.Medium); if (sub.isNotEmpty()) Text(sub, color = Color.Gray, fontSize = 14.sp) }
            Switch(value, onChange) }

    // ---------- plain grey 3D cube (replaces the colorful Minecraft emoji) ----------
    @Composable private fun CubeIcon(s: androidx.compose.ui.unit.Dp) {
        Canvas(Modifier.size(s)) {
            val w = size.width; val h = size.height
            val top = Path().apply { moveTo(w * .5f, h * .05f); lineTo(w * .93f, h * .27f); lineTo(w * .5f, h * .5f); lineTo(w * .07f, h * .27f); close() }
            val left = Path().apply { moveTo(w * .07f, h * .27f); lineTo(w * .5f, h * .5f); lineTo(w * .5f, h * .95f); lineTo(w * .07f, h * .72f); close() }
            val right = Path().apply { moveTo(w * .93f, h * .27f); lineTo(w * .5f, h * .5f); lineTo(w * .5f, h * .95f); lineTo(w * .93f, h * .72f); close() }
            drawPath(top, Color(0xFFE6E6E6)); drawPath(left, Color(0xFF9A9A9A)); drawPath(right, Color(0xFF666666))
            listOf(top, left, right).forEach { drawPath(it, Color.White.copy(alpha = .35f), style = Stroke(width = 2f)) }
        }
    }

    // ---------- Home ----------
    @Composable private fun HomePage(accent: Color, launch: () -> Unit, go: (String) -> Unit, importIt: () -> Unit, libVersion: Int, openFile: (File) -> Unit) {
        var menu by remember { mutableStateOf(false) }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CubeIcon(64.dp); Spacer(Modifier.width(18.dp))
                Column(Modifier.weight(1f)) {
                    Text("Minecraft", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    Text("Bedrock Edition", fontSize = 20.sp, color = accent)
                    Box {
                        Row(Modifier.clickable { menu = true }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(10.dp).clip(CircleShape).background(Color(0xFF22C55E))); Spacer(Modifier.width(8.dp))
                            Text("Current Instance: Default  ⌄", fontSize = 16.sp) }
                        DropdownMenu(menu, { menu = false }) { DropdownMenuItem({ Text("Default") }, { menu = false }) }
                    }
                }
                Box(Modifier.width(190.dp).height(60.dp).clip(RoundedCornerShape(18.dp)).background(accent.copy(alpha = .22f))
                    .border(2.dp, accent, RoundedCornerShape(18.dp)).clickable { launch() }, contentAlignment = Alignment.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Outlined.RocketLaunch, null, tint = accent); Spacer(Modifier.width(10.dp)); Text("Launch", fontSize = 20.sp, fontWeight = FontWeight.SemiBold); Spacer(Modifier.width(8.dp)); Icon(Icons.Outlined.ArrowForward, null) } }
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            HomeCard(Modifier.weight(1f), Icons.Outlined.Extension, "Mods", "Add and manage your mods easily.", accent) { go("mods") }
            HomeCard(Modifier.weight(1f), Icons.Outlined.PlayArrow, "Instances", "Create and manage your game instances.", accent) { go("inst") }
            HomeCard(Modifier.weight(1f), Icons.Outlined.Palette, "Cosmetics", "Add your skins and capes.", accent) { go("cosm") }
        }
        Spacer(Modifier.height(14.dp))
        Panel(Modifier.clickable { importIt() }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.FileDownload, null, Modifier.size(44.dp), tint = accent); Spacer(Modifier.width(18.dp))
                Column(Modifier.weight(1f)) { Text("Import World / Packs", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("Import worlds, texture packs, behavior packs and more.", color = Color.Gray) }
                Icon(Icons.Outlined.ArrowForward, null, tint = accent, modifier = Modifier.size(30.dp))
            }
        }
        Spacer(Modifier.height(14.dp))
        Panel {
            Text("Get worlds & packs", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text("Download .mcworld / .mcpack / .mcaddon files, then import them.", color = Color.Gray, modifier = Modifier.padding(vertical = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SiteTile(Modifier.weight(1f), "CurseForge", "curseforge.com", "https://www.curseforge.com/minecraft-bedrock", Color(0xFFF16436), "C")
                SiteTile(Modifier.weight(1f), "MCPEDL", "mcpedl.com", "https://mcpedl.com", Color(0xFF3FA34D), "M")
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            LibraryPanel(Modifier.weight(1f), "My Worlds", "worlds", libVersion, openFile)
            LibraryPanel(Modifier.weight(1f), "My Resource Packs", "resource", libVersion, openFile)
            LibraryPanel(Modifier.weight(1f), "My Behavior Packs", "behavior", libVersion, openFile)
        }
    }

    /** The site's own icon, fetched from the internet; a colored letter shows until it loads. */
    @Composable private fun SiteIcon(domain: String, fallback: Color, letter: String) {
        var bmp by remember { mutableStateOf<ImageBitmap?>(null) }
        LaunchedEffect(domain) {
            bmp = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                try { java.net.URL("https://www.google.com/s2/favicons?domain=$domain&sz=128").openStream().use { BitmapFactory.decodeStream(it)?.asImageBitmap() } }
                catch (e: Exception) { null } }
        }
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(fallback), contentAlignment = Alignment.Center) {
            val b = bmp
            if (b != null) Image(b, null, Modifier.fillMaxSize()) else Text(letter, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        }
    }

    @Composable private fun SiteTile(mod: Modifier, name: String, domain: String, url: String, color: Color, letter: String) =
        Row(mod.clip(RoundedCornerShape(14.dp)).border(1.dp, Color.Gray.copy(alpha = .4f), RoundedCornerShape(14.dp)).clickable { openUrl(url) }.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            SiteIcon(domain, color, letter); Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(name, fontSize = 18.sp, fontWeight = FontWeight.SemiBold); Text(domain, color = Color.Gray, fontSize = 13.sp) }
            Icon(Icons.Outlined.ArrowForward, null)
        }

    /** Files you imported through Moonlight (Android doesn't let apps read Minecraft's own folders). */
    @Composable private fun LibraryPanel(mod: Modifier, title: String, kind: String, ver: Int, openFile: (File) -> Unit) {
        var tick by remember { mutableStateOf(0) }
        val files = remember(ver, tick) { PackBuilder.library(this@MainActivity, kind).listFiles()?.sortedBy { it.name } ?: emptyList() }
        Panel(mod) {
            Text("$title (${files.size})", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            if (files.isEmpty()) Text("Nothing imported yet.", color = Color.Gray, modifier = Modifier.padding(top = 8.dp))
            files.forEach { f ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(f.nameWithoutExtension, Modifier.weight(1f), maxLines = 1, fontSize = 15.sp)
                    TextButton({ openFile(f) }) { Text("Open") }
                    TextButton({ f.delete(); tick++ }) { Text("Delete") }
                }
            }
        }
    }

    @Composable private fun HomeCard(mod: Modifier, icon: ImageVector, title: String, desc: String, accent: Color, onClick: () -> Unit) =
        Panel(mod.clickable { onClick() }) {
            Row(verticalAlignment = Alignment.Top) {
                Icon(icon, null, Modifier.size(38.dp), tint = accent); Spacer(Modifier.weight(1f))
                Box(Modifier.clip(RoundedCornerShape(12.dp)).background(accent.copy(alpha = .2f)).padding(horizontal = 14.dp, vertical = 8.dp)) { Text("Manage", fontSize = 14.sp) }
            }
            Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
            Text(desc, color = Color.Gray, modifier = Modifier.padding(vertical = 6.dp))
            Icon(Icons.Outlined.ArrowForward, null, tint = accent)
        }

    // ---------- Cosmetics: your skins and capes ----------
    @Composable private fun CosmeticsPage(accent: Color) {
        Text("Cosmetics", fontSize = 28.sp, color = accent, fontWeight = FontWeight.Bold)
        Text("Add your skins and capes", color = Color.Gray, modifier = Modifier.padding(bottom = 12.dp))
        CosmeticSection("Skins", "skins", "skin_sel", accent)
        Spacer(Modifier.height(12.dp))
        CosmeticSection("Capes", "capes", "cape_sel", accent)
        Spacer(Modifier.height(12.dp))
        Panel {
            Text("Using them in Minecraft", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text("Skins: tap Save under a skin (it goes to Downloads/Moonlight), then in Minecraft open the Dressing Room, choose Classic, Choose New Skin, Import, and pick the file.", color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
            Text("Capes: Moonlight stores and previews them, but Minecraft Bedrock can't load a cape from a file, so they can't be applied in game yet.", color = Color.Gray, modifier = Modifier.padding(top = 6.dp))
        }
    }

    private fun exportToDownloads(f: File): String = try {
        if (Build.VERSION.SDK_INT < 29) "Needs Android 10 or newer"
        else {
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, f.name); put(MediaStore.Downloads.MIME_TYPE, "image/png")
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/Moonlight") }
            val u = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
            contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
            "Saved to Downloads/Moonlight"
        }
    } catch (e: Exception) { "Couldn't save: ${e.message}" }

    @Composable private fun CosmeticSection(title: String, dirName: String, selKey: String, accent: Color) {
        val dir = remember { File(filesDir, dirName).apply { mkdirs() } }
        val files = remember { mutableStateListOf<File>().apply { addAll(dir.listFiles()?.sortedBy { it.name } ?: emptyList()) } }
        var sel by remember { mutableStateOf(prefs.getString(selKey, "")!!) }
        val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) try {
                var name = "${System.currentTimeMillis()}.png"
                contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name }
                if (!name.lowercase().endsWith(".png")) toast("Pick a PNG image")
                else {
                    val f = File(dir, name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                    contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    if (files.none { it.path == f.path }) files.add(f)
                }
            } catch (e: Exception) { toast("Couldn't add that file") }
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, Modifier.weight(1f), fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Button({ pick.launch("image/png") }, Modifier.height(44.dp)) { Text("Add ${title.dropLast(1).lowercase()}") }
            }
            if (files.isEmpty()) Text("Nothing here yet.", color = Color.Gray, modifier = Modifier.padding(top = 8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                files.toList().forEach { f ->
                    val bmp = remember(f.path) { BitmapFactory.decodeFile(f.path)?.asImageBitmap() }
                    val on = sel == f.name
                    Column(Modifier.width(140.dp).clip(RoundedCornerShape(14.dp))
                        .border(if (on) 3.dp else 1.dp, if (on) accent else Color.Gray.copy(alpha = .4f), RoundedCornerShape(14.dp))
                        .clickable { sel = f.name; prefs.edit().putString(selKey, f.name).apply() }.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally) {
                        if (bmp != null) Image(bmp, null, Modifier.size(104.dp), contentScale = ContentScale.Fit, filterQuality = FilterQuality.None)
                        Text(f.nameWithoutExtension, maxLines = 1, fontSize = 12.sp)
                        Row {
                            if (dirName == "skins") TextButton({ toast(exportToDownloads(f)) }) { Text("Save", fontSize = 12.sp) }
                            TextButton({ f.delete(); files.remove(f); if (sel == f.name) { sel = ""; prefs.edit().putString(selKey, "").apply() } }) { Text("Delete", fontSize = 12.sp) }
                        }
                    }
                }
            }
        }
    }

    // ---------- Mods ----------
    @Composable private fun ModsPage(feats: MutableList<Feature>, importIt: () -> Unit, say: (String) -> Unit) {
        var n by remember { mutableStateOf("") }; var c by remember { mutableStateOf("") }
        Panel {
            Text("Get mods", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text("Download .mcpack / .mcworld / .mcaddon files, then import them.", color = Color.Gray, modifier = Modifier.padding(vertical = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button({ openUrl("https://mcpedl.com") }, Modifier.height(48.dp)) { Text("MCPEDL") }
                Button({ openUrl("https://www.curseforge.com/minecraft-bedrock") }, Modifier.height(48.dp)) { Text("CurseForge") }
                OutlinedButton(importIt, Modifier.height(48.dp)) { Icon(Icons.Outlined.FileDownload, null, Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)); Text("Import world / pack") }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Panel(Modifier.weight(1f)) {
                Text("Add custom feature", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                OutlinedTextField(n, { n = it }, label = { Text("Feature name") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                OutlinedTextField(c, { c = it }, label = { Text("Paste code") }, modifier = Modifier.fillMaxWidth().height(150.dp).padding(top = 8.dp))
                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button({ if (c.isNotBlank()) { feats.add(Feature(n.ifBlank { "Feature ${feats.size + 1}" }, c)); save(feats); n = ""; c = ""; say("Added.") } }, Modifier.height(48.dp)) { Text("Add") }
                    OutlinedButton({ say(PackBuilder.buildAndImport(this@MainActivity, feats, "1.15.0") ?: "Sent to Minecraft") }, Modifier.height(48.dp)) { Text("Build & import") }
                }
            }
            Panel(Modifier.weight(1f)) {
                Text("Your mods (${feats.size})", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                if (feats.isEmpty()) Text("No mods yet.", color = Color.Gray, modifier = Modifier.padding(top = 8.dp))
                feats.toList().forEach { f ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(f.name, Modifier.weight(1f), fontSize = 17.sp)
                        Switch(f.on, { v -> val i = feats.indexOf(f); if (i >= 0) { feats[i] = f.copy(on = v); save(feats) } })
                        TextButton({ feats.remove(f); save(feats) }) { Text("Delete") }
                    }
                }
            }
        }
    }

    // ---------- Cosmetics (theme, color, transparency, background) ----------
    @OptIn(ExperimentalLayoutApi::class)
    @Composable private fun PersonalizationPage(
        accent: Color, setAccent: (Color) -> Unit, mode: String, setMode: (String) -> Unit,
        hasBg: Boolean, pickBg: () -> Unit, clearBg: () -> Unit, bright: Float, setBright: (Float) -> Unit, blurV: Float, setBlur: (Float) -> Unit
    ) {
        Panel {
            Text("Theme Mode", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("system" to "Follow System", "light" to "Light Mode", "dark" to "Dark Mode").forEach { (k, v) ->
                    val sel = mode == k
                    Box(Modifier.weight(1f).height(52.dp).clip(RoundedCornerShape(12.dp)).background(if (sel) accent.copy(alpha = .25f) else Color.Transparent)
                        .border(1.dp, Color.Gray.copy(alpha = .4f), RoundedCornerShape(12.dp)).clickable { setMode(k) }, contentAlignment = Alignment.Center) {
                        Text(v, color = if (sel) accent else MaterialTheme.colorScheme.onSurface) } }
            }
        }
        Spacer(Modifier.height(12.dp))
        Panel {
            Text("Theme Color", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            val colors = listOf(0xFF2BB39A, 0xFF4AA8F0, 0xFF6B4EF0, 0xFFA032B8, 0xFFE0307F, 0xFFE5465A, 0xFFF96C4C, 0xFFF9A62B, 0xFFFCD327, 0xFF6FCF6F, 0xFF2FD6D6, 0xFF2BBCF5,
                0xFF7E4FC9, 0xFFE00063, 0xFFEA3333, 0xFF4552C0, 0xFF1E6FD0, 0xFF0A8DC4, 0xFF12A0A0, 0xFF0A9C78, 0xFF2E9440, 0xFF8C8418, 0xFF808080, 0xFF4AF5A0, 0xFFCFEE38)
            FlowRow(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                colors.forEach { hex ->
                    val col = Color(hex)
                    Box(Modifier.size(46.dp).clip(CircleShape).background(col).border(if (col == accent) 3.dp else 0.dp, Color.White, CircleShape).clickable { setAccent(col) },
                        contentAlignment = Alignment.Center) { if (col == accent) Text("✓", color = Color.White) } }
            }
            var hex by remember { mutableStateOf("") }
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(hex, { hex = it }, Modifier.weight(1f), singleLine = true, label = { Text("Custom Color (#RRGGBB or R,G,B)") })
                Button({ parseColor(hex)?.let { setAccent(it) } ?: toast("Use #RRGGBB or R,G,B") }, Modifier.height(54.dp)) { Text("Apply") }
            }
        }
        Spacer(Modifier.height(12.dp))
        Panel {
            Text("Transparency  ${transp.toInt()}", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text("0 = solid, 100 = fully see-through", color = Color.Gray)
            Slider(transp, { transp = it; prefs.edit().putFloat("transp", it).apply() }, valueRange = 0f..100f)
        }
        Spacer(Modifier.height(12.dp))
        Panel {
            Text("Background", fontSize = 20.sp, fontWeight = FontWeight.SemiBold); Text("Choose a photo or GIF (GIFs animate on Android 9+)", color = Color.Gray)
            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (hasBg) "Background selected" else "No background selected", Modifier.weight(1f))
                if (hasBg) TextButton(clearBg) { Text("Remove") }
                Button(pickBg, Modifier.height(48.dp)) { Text("Select background") }
            }
            Text("Brightness  ${bright.toInt()}"); Slider(bright, setBright, valueRange = 0f..100f)
            Text("Background blur  ${blurV.toInt()}"); Slider(blurV, setBlur, valueRange = 0f..100f)
        }
    }

    // ---------- Settings ----------
    @Composable private fun SettingsPage(tab: Int, setTab: (Int) -> Unit, personalization: @Composable () -> Unit) {
        Text("Settings", fontSize = 28.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        Row(Modifier.padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Basic Settings", "Personalization", "Updates", "Migration").forEachIndexed { i, t ->
                Box(Modifier.clip(RoundedCornerShape(24.dp)).background(if (i == tab) MaterialTheme.colorScheme.primary else Color.Transparent).clickable { setTab(i) }.padding(horizontal = 20.dp, vertical = 12.dp)) {
                    Text(t, fontSize = 16.sp, color = if (i == tab) Color.White else Color.Gray, fontWeight = if (i == tab) FontWeight.Bold else FontWeight.Normal) }
            }
        }
        when (tab) {
            0 -> Panel {
                var lc by remember { mutableStateOf(prefs.getBoolean("logcat", false)) }; var fg by remember { mutableStateOf(prefs.getBoolean("fgsvc", false)) }; var ov by remember { mutableStateOf(prefs.getBoolean("ov_service", true)) }
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("Language", fontSize = 18.sp, fontWeight = FontWeight.Medium); Text("English", color = Color.Gray) }
                    OutlinedButton({ toast("More languages soon") }) { Text("English") } }
                SwitchRow("Logcat overlay", "", lc) { lc = it; prefs.edit().putBoolean("logcat", it).apply() }
                SwitchRow("In-game button", "Shows the \"?\" button over Minecraft (Mods, HUD Editor, Settings). Needs \"Display over other apps\".", ov) {
                    ov = it; prefs.edit().putBoolean("ov_service", it).apply()
                    if (it) ensureOverlay() else stopService(Intent(this@MainActivity, OverlayService::class.java)) }
                SwitchRow("Foreground service", "Keep Minecraft running when you switch apps by preventing Bedrock from suspending the active session.", fg) { fg = it; prefs.edit().putBoolean("fgsvc", it).apply() }
            }
            1 -> personalization()
            2 -> Panel { Text("Moonlight 1.0.0", fontSize = 18.sp); Text("You're up to date.", color = Color.Gray) }
            else -> Panel { Text("Nothing to migrate.", fontSize = 18.sp) }
        }
    }

    private fun parseColor(s: String): Color? {
        val t = s.trim()
        Regex("^#?([0-9a-fA-F]{6})$").matchEntire(t)?.let { return Color(0xFF000000 or it.groupValues[1].toLong(16)) }
        Regex("^(\\d{1,3})\\s*,\\s*(\\d{1,3})\\s*,\\s*(\\d{1,3})$").matchEntire(t)?.let {
            val (r, g, b) = it.destructured; if (listOf(r, g, b).all { v -> v.toInt() < 256 }) return Color(r.toInt(), g.toInt(), b.toInt()) }
        return null
    }
}
