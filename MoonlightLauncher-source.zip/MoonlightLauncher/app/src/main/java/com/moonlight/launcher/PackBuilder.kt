package com.moonlight.launcher

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class Feature(val name: String, val code: String, var on: Boolean = true)

object PackBuilder {
    /** worlds / resource / behavior, decided from the file name or the pack's manifest. */
    fun classify(f: File): String {
        val n = f.name.lowercase()
        if (n.endsWith(".mcworld") || n.endsWith(".mctemplate")) return "worlds"
        if (n.endsWith(".mcaddon")) return "behavior"
        try {
            java.util.zip.ZipInputStream(f.inputStream()).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    if (e.name.substringAfterLast('/') == "manifest.json" && e.name.count { it == '/' } <= 1) {
                        val mods = org.json.JSONObject(z.readBytes().toString(Charsets.UTF_8)).optJSONArray("modules")
                        for (i in 0 until (mods?.length() ?: 0)) if (mods!!.getJSONObject(i).optString("type") == "resources") return "resource"
                        return "behavior"
                    }
                    e = z.nextEntry
                }
            }
        } catch (_: Exception) {}
        return "resource"
    }

    fun library(c: Context, kind: String) = File(c.filesDir, "library/$kind").apply { mkdirs() }

    /** Hands a saved file to Minecraft so it imports it. */
    fun openFile(c: Context, f: File): String? {
        val u = FileProvider.getUriForFile(c, "com.moonlight.launcher.files", f)
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/octet-stream")
            .setPackage(MinecraftLoader.PKG).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { c.startActivity(i); null } catch (e: Exception) { "Minecraft couldn't open it: ${e.message}" }
    }

    /** Picks up a .mcworld / .mcpack / .mcaddon / .mctemplate, keeps a copy in Moonlight's library, and opens it in Minecraft. */
    fun importFile(c: Context, uri: android.net.Uri): String? {
        var name = "import.mcpack"
        c.contentResolver.query(uri, null, null, null, null)?.use {
            val i = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && it.moveToFirst()) name = it.getString(i) ?: name
        }
        if (listOf(".mcworld", ".mcpack", ".mcaddon", ".mctemplate").none { name.lowercase().endsWith(it) })
            return "Pick a .mcworld, .mcpack, .mcaddon or .mctemplate file."
        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val tmp = File(File(c.cacheDir, "packs").apply { mkdirs() }, safe)
        c.contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } } ?: return "Couldn't read that file."
        val dest = File(library(c, classify(tmp)), safe)
        tmp.copyTo(dest, overwrite = true); tmp.delete()
        return openFile(c, dest)
    }

    /** Bundles every enabled feature into a Script API behavior pack and hands it to Minecraft to import. */
    fun buildAndImport(c: Context, features: List<Feature>, serverVersion: String): String? {
        val on = features.filter { it.on }
        if (on.isEmpty()) return "Turn on at least one feature."
        val dir = File(c.cacheDir, "packs").apply { mkdirs() }
        val out = File(dir, "MoonlightFeatures.mcpack")
        ZipOutputStream(out.outputStream()).use { z ->
            fun put(n: String, t: String) { z.putNextEntry(ZipEntry(n)); z.write(t.toByteArray()); z.closeEntry() }
            on.forEachIndexed { i, f -> put("scripts/feature$i.js", f.code) }
            put("scripts/main.js", on.indices.joinToString("\n") { "import \"./feature$it.js\";" })
            put("manifest.json", """{
 "format_version": 2,
 "header": {"name":"Moonlight Features","description":"MoonlightLauncher features","uuid":"${UUID.randomUUID()}","version":[1,0,0],"min_engine_version":[1,21,0]},
 "modules": [{"type":"script","language":"javascript","uuid":"${UUID.randomUUID()}","version":[1,0,0],"entry":"scripts/main.js"}],
 "dependencies": [{"module_name":"@minecraft/server","version":"$serverVersion"}]
}""")
        }
        val uri = FileProvider.getUriForFile(c, "com.moonlight.launcher.files", out)
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/octet-stream")
            .setPackage(MinecraftLoader.PKG).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { c.startActivity(i); null } catch (e: Exception) { "Couldn't hand the pack to Minecraft: ${e.message}" }
    }
}
