package com.moonlight.launcher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP

/**
 * Draws the "?" button above EVERY app, including normal Minecraft, so it is always there.
 * Needs the "Display over other apps" permission.
 */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var hud: Overlay.Hud
    private var hudView: View? = null
    private var button: View? = null
    private var panel: View? = null

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("moon", "Moonlight in-game button", NotificationManager.IMPORTANCE_MIN))
        startForeground(1, Notification.Builder(this, "moon").setContentTitle("Moonlight is running").setContentText("In-game button is on").setSmallIcon(android.R.drawable.star_on).build())
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = LP.TYPE_APPLICATION_OVERLAY

        // on-screen mod labels (don't block touches unless you're editing them)
        val hlp = LP(-1, -1, type, LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCHABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        hud = Overlay.Hud(this) { touchable ->
            hlp.flags = if (touchable) hlp.flags and LP.FLAG_NOT_TOUCHABLE.inv() else hlp.flags or LP.FLAG_NOT_TOUCHABLE
            try { wm.updateViewLayout(hudView, hlp) } catch (_: Throwable) {} }
        hudView = hud.root; wm.addView(hud.root, hlp); hud.refresh()

        // the button
        val size = Overlay.dp(this, 52)
        val blp = LP(size, size, type, LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = Overlay.dp(this@OverlayService, 16); y = Overlay.dp(this@OverlayService, 70) }
        val btn = Overlay.floatingButton(this, { dx, dy -> blp.x += dx; blp.y += dy; try { wm.updateViewLayout(button, blp) } catch (_: Throwable) {} }) { openPanel() }
        button = btn; wm.addView(btn, blp)
    }

    private fun openPanel() {
        if (panel != null) return
        val lp = LP(-1, -1, LP.TYPE_APPLICATION_OVERLAY, LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply {
            softInputMode = LP.SOFT_INPUT_ADJUST_RESIZE }
        val host = object : Overlay.Host {
            override fun blur(radiusPx: Float) {
                if (Build.VERSION.SDK_INT >= 31) try {
                    lp.flags = if (radiusPx > 0.5f) lp.flags or LP.FLAG_BLUR_BEHIND else lp.flags and LP.FLAG_BLUR_BEHIND.inv()
                    lp.blurBehindRadius = radiusPx.toInt()
                    if (panel?.isAttachedToWindow == true) wm.updateViewLayout(panel, lp)
                } catch (_: Throwable) {} }
            override fun editHud(on: Boolean) = hud.edit(on)
            override fun refreshHud() = hud.refresh()
        }
        val v = Overlay.buildPanel(this, host) { closePanel() }
        panel = v; wm.addView(v, lp)
    }

    private fun closePanel() { panel?.let { try { wm.removeView(it) } catch (_: Throwable) {} }; panel = null }

    override fun onDestroy() {
        closePanel()
        listOf(button, hudView).forEach { v -> v?.let { try { wm.removeView(it) } catch (_: Throwable) {} } }
        super.onDestroy()
    }
}
