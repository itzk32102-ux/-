package com.moonlight.launcher

import android.app.Activity
import android.app.Application
import android.os.Bundle

class MoonApp : Application() {
    override fun onCreate() {
        super.onCreate()
        getSharedPreferences("moon", MODE_PRIVATE).let { p ->
            // last game start never reached the game screen = it crashed: use normal Minecraft from now on
            if (p.getBoolean("pending", false)) p.edit().putBoolean("fallback", true).putBoolean("pending", false).apply()
        }
        MinecraftLoader.prewarm(this)   // always on
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            // Minecraft's activity runs inside our process, so every screen of the game
            // (loading, home, pause menu, in-world) gets the Moonlight button on top.
            override fun onActivityResumed(a: Activity) {
                if (a.javaClass.name == MinecraftLoader.PKG + ".MainActivity") {
                    val p = getSharedPreferences("moon", MODE_PRIVATE)
                    p.edit().putBoolean("pending", false).apply()
                    if (p.getBoolean("fps_boost", false)) Booster.apply(a)
                    // the screen-wide button (OverlayService) already covers Minecraft; only add our own if it's off
                    if (!p.getBoolean("ov_service", true)) Overlay.attach(a)
                }
            }
            override fun onActivityCreated(a: Activity, s: Bundle?) {}
            override fun onActivityStarted(a: Activity) {}
            override fun onActivityPaused(a: Activity) {}
            override fun onActivityStopped(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, s: Bundle) {}
            override fun onActivityDestroyed(a: Activity) {}
        })
    }
}
