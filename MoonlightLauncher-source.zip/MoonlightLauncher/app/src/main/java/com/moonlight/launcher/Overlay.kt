package com.moonlight.launcher

import android.app.Activity
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.Editable
import android.text.TextWatcher
import android.util.Base64
import android.util.TypedValue
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

/** The "?" button and its menu (Mods, HUD Editor, Settings). Used inside Minecraft AND as a screen-wide overlay. */
object Overlay {
    interface Host { fun blur(radiusPx: Float); fun editHud(on: Boolean); fun refreshHud() }

    val COLORS = intArrayOf(0xFF6B4EF0.toInt(), 0xFF2BB39A.toInt(), 0xFF4AA8F0.toInt(), 0xFFA032B8.toInt(), 0xFFE0307F.toInt(), 0xFFE5465A.toInt(),
        0xFFF96C4C.toInt(), 0xFFF9A62B.toInt(), 0xFFFCD327.toInt(), 0xFF6FCF6F.toInt(), 0xFF2FD6D6.toInt(), 0xFF2BBCF5.toInt(),
        0xFF7E4FC9.toInt(), 0xFFE00063.toInt(), 0xFF4552C0.toInt(), 0xFF4AF5A0.toInt())
    private const val TAG = "moon_overlay"
    private const val BG = 0xFF1B1F23.toInt()
    private const val CARD = 0xFF2A2F33.toInt()
    private const val TILE = 0xFF3A4046.toInt()
    private const val MUTED = 0xFFA9B0B5.toInt()

    fun pf(c: Context) = c.getSharedPreferences("moon", Context.MODE_PRIVATE)
    private fun ui(c: Context): Float { val m = c.resources.displayMetrics; return (minOf(m.widthPixels, m.heightPixels) / m.density / 430f).coerceIn(0.55f, 1f) }
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density * ui(c)).toInt()
    private fun round(col: Int, r: Int) = GradientDrawable().apply { setColor(col); cornerRadius = r.toFloat() }
    private fun tv(c: Context, t: String, sp: Float, col: Int = Color.WHITE, bold: Boolean = false) = TextView(c).apply {
        text = t; setTextSize(TypedValue.COMPLEX_UNIT_PX, sp * c.resources.displayMetrics.density * ui(c)); setTextColor(col); if (bold) typeface = Typeface.DEFAULT_BOLD }
    private fun toast(c: Context, t: String) = Toast.makeText(c, t, Toast.LENGTH_SHORT).show()
    fun accent(c: Context) = pf(c).getInt("accent", COLORS[0])
    private fun mods(c: Context) = JSONArray(pf(c).getString("features", "[]"))
    private fun saveMods(c: Context, a: JSONArray) = pf(c).edit().putString("features", a.toString()).apply()
    private fun icon(c: Context): Bitmap { val b = Base64.decode(IconData.B64, Base64.DEFAULT); return BitmapFactory.decodeByteArray(b, 0, b.size) }

    // ---------------- the draggable "?" button ----------------
    fun floatingButton(c: Context, onMove: (Int, Int) -> Unit, onTap: () -> Unit): View {
        val iv = ImageView(c).apply {
            setImageBitmap(icon(c)); scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.BLACK); setStroke(dp(c, 2), Color.WHITE) }
            clipToOutline = true; elevation = 12f }
        var lx = 0f; var ly = 0f; var dist = 0f
        iv.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY; dist = 0f }
                MotionEvent.ACTION_MOVE -> { val dx = e.rawX - lx; val dy = e.rawY - ly; lx = e.rawX; ly = e.rawY; dist += Math.abs(dx) + Math.abs(dy); onMove(Math.round(dx), Math.round(dy)) }
                MotionEvent.ACTION_UP -> if (dist < dp(c, 10)) onTap()
            }
            true
        }
        return iv
    }

    // ---------------- HUD: your mods shown on the game screen ----------------
    class Hud(private val c: Context, private val setTouchable: (Boolean) -> Unit) {
        val root = FrameLayout(c)
        private var editing = false
        fun refresh() {
            root.removeAllViews()
            val p = pf(c); val arr = mods(c)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i); val name = o.getString("n")
                if (!o.getBoolean("on") || !p.getBoolean("hud_show_$name", false)) continue
                val t = tv(c, name, 14f).apply {
                    setPadding(dp(c, 10), dp(c, 5), dp(c, 10), dp(c, 5))
                    background = GradientDrawable().apply { setColor(0x99000000.toInt()); cornerRadius = dp(c, 8).toFloat(); if (editing) setStroke(dp(c, 2), accent(c)) } }
                val lp = FrameLayout.LayoutParams(-2, -2).apply { leftMargin = p.getInt("hud_x_$name", dp(c, 120)); topMargin = p.getInt("hud_y_$name", dp(c, 20) + i * dp(c, 34)) }
                if (editing) {
                    var lx = 0f; var ly = 0f
                    t.setOnTouchListener { v, e ->
                        when (e.actionMasked) {
                            MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY }
                            MotionEvent.ACTION_MOVE -> { val l = v.layoutParams as FrameLayout.LayoutParams
                                l.leftMargin += Math.round(e.rawX - lx); l.topMargin += Math.round(e.rawY - ly); lx = e.rawX; ly = e.rawY; v.layoutParams = l }
                            MotionEvent.ACTION_UP -> { val l = v.layoutParams as FrameLayout.LayoutParams
                                pf(c).edit().putInt("hud_x_$name", l.leftMargin).putInt("hud_y_$name", l.topMargin).apply() }
                        }
                        true
                    }
                }
                root.addView(t, lp)
            }
            if (editing) root.addView(tv(c, "Done", 16f, Color.WHITE, true).apply {
                background = round(accent(c), dp(c, 14)); setPadding(dp(c, 24), dp(c, 10), dp(c, 24), dp(c, 10)); setOnClickListener { edit(false) } },
                FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(c, 12) })
        }
        fun edit(on: Boolean) { editing = on; setTouchable(on); refresh() }
    }

    // ---------------- inside Minecraft (when it runs in Moonlight) ----------------
    fun attach(a: Activity) {
        val decor = a.window.decorView as? FrameLayout ?: return
        if (decor.findViewWithTag<View>(TAG) != null) return
        val root = FrameLayout(a).apply { tag = TAG }
        val hud = Hud(a) { }
        root.addView(hud.root, FrameLayout.LayoutParams(-1, -1)); hud.refresh()
        var btn: View? = null
        var pv: View? = null
        val host = object : Host {
            override fun blur(radiusPx: Float) { if (Build.VERSION.SDK_INT >= 31) try {
                decor.getChildAt(0)?.setRenderEffect(if (radiusPx > 0.5f) RenderEffect.createBlurEffect(radiusPx, radiusPx, Shader.TileMode.CLAMP) else null) } catch (_: Throwable) {} }
            override fun editHud(on: Boolean) = hud.edit(on)
            override fun refreshHud() = hud.refresh()
        }
        btn = floatingButton(a, { dx, dy -> btn?.let { it.x += dx; it.y += dy } }) {
            if (pv == null) {
                pv = buildPanel(a, host) { pv?.let { root.removeView(it) }; pv = null; host.blur(0f) }
                root.addView(pv, FrameLayout.LayoutParams(-1, -1))
            }
        }
        root.addView(btn, FrameLayout.LayoutParams(dp(a, 52), dp(a, 52)).apply { leftMargin = dp(a, 16); topMargin = dp(a, 70) })
        decor.addView(root, FrameLayout.LayoutParams(-1, -1))
    }

    // ---------------- the menu ----------------
    fun buildPanel(c: Context, host: Host, close: () -> Unit): View {
        val p = pf(c)
        val scrim = FrameLayout(c).apply { isClickable = true }
        val card = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; isClickable = true }
        scrim.addView(card, FrameLayout.LayoutParams(-1, -1).apply { setMargins(dp(c, 40), dp(c, 12), dp(c, 40), dp(c, 12)) })
        var page = "Mods"; var filter = "All"; var query = ""; var addOpen = false

        fun look() {
            val a = ((100f - p.getFloat("ov_transp", 10f)) / 100f * 255f).toInt()
            card.background = round((a shl 24) or (BG and 0x00FFFFFF), dp(c, 22))
            scrim.setBackgroundColor(Color.argb(((100f - p.getFloat("ov_bright", 100f)) * 2.2f).toInt().coerceIn(0, 220), 0, 0, 0))
            host.blur(p.getFloat("ov_blur", 0f) / 100f * 25f * c.resources.displayMetrics.density)
        }

        fun slider(parent: LinearLayout, label: String, key: String, def: Float) {
            val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(c, 6), 0, dp(c, 6)) }
            val v = tv(c, "${p.getFloat(key, def).toInt()}", 14f, MUTED)
            row.addView(tv(c, label, 15f), LinearLayout.LayoutParams(dp(c, 130), -2))
            row.addView(SeekBar(c).apply {
                max = 100; progress = p.getFloat(key, def).toInt()
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, pr: Int, user: Boolean) { v.text = "$pr"; p.edit().putFloat(key, pr.toFloat()).apply(); look() }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(v, LinearLayout.LayoutParams(dp(c, 40), -2))
            parent.addView(row)
        }

        fun pill(text: String, on: Boolean, click: () -> Unit) = tv(c, text, 13f, if (on) Color.WHITE else Color.WHITE, true).apply {
            background = round(if (on) accent(c) else BG, dp(c, 12)); setPadding(dp(c, 14), dp(c, 7), dp(c, 14), dp(c, 7)); setOnClickListener { click() } }

        fun render() {
            card.removeAllViews()
            val acc = accent(c)
            // sidebar
            val side = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(c, 12), dp(c, 12), dp(c, 12), dp(c, 12)) }
            side.addView(ImageView(c).apply { setImageBitmap(icon(c)); scaleType = ImageView.ScaleType.CENTER_CROP; background = round(Color.BLACK, dp(c, 14)); clipToOutline = true },
                LinearLayout.LayoutParams(dp(c, 48), dp(c, 48)).apply { bottomMargin = dp(c, 14) })
            listOf("Mods", "HUD Editor", "Settings").forEach { n ->
                side.addView(tv(c, n, 16f, if (page == n) Color.WHITE else MUTED, page == n).apply {
                    background = if (page == n) round(acc, dp(c, 12)) else null
                    setPadding(dp(c, 12), dp(c, 12), dp(c, 12), dp(c, 12)); setOnClickListener { page = n; render() } })
            }
            card.addView(side, LinearLayout.LayoutParams(dp(c, 150), -1))

            val content = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(c, 8), dp(c, 12), dp(c, 14), dp(c, 8)) }
            card.addView(content, LinearLayout.LayoutParams(0, -1, 1f))
            val top = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val body = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
            if (page == "Mods") top.addView(EditText(c).apply {
                hint = "Search mods..."; setHintTextColor(0xFF8A9096.toInt()); setTextColor(Color.WHITE); setTextSize(TypedValue.COMPLEX_UNIT_PX, 15f * c.resources.displayMetrics.density * ui(c))
                background = round(0xFF22272B.toInt(), dp(c, 14)); setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8)); isSingleLine = true; setText(query)
                addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(s: Editable?) { if (s.toString() != query) { query = s.toString(); fillMods(c, body, p, filter, query, acc, { render() }) } }
                    override fun beforeTextChanged(s: CharSequence?, st: Int, ct: Int, af: Int) {}
                    override fun onTextChanged(s: CharSequence?, st: Int, b: Int, ct: Int) {}
                })
            }, LinearLayout.LayoutParams(0, dp(c, 44), 1f)) else top.addView(View(c), LinearLayout.LayoutParams(0, 1, 1f))
            top.addView(tv(c, "X", 18f, Color.WHITE, true).apply { gravity = Gravity.CENTER; background = round(0xFF5A2A30.toInt(), dp(c, 22)); setOnClickListener { close() } },
                LinearLayout.LayoutParams(dp(c, 44), dp(c, 44)).apply { leftMargin = dp(c, 10) })
            content.addView(top)

            when (page) {
                "Mods" -> {
                    val bar = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(c, 8), 0, dp(c, 6)) }
                    listOf("All", "Favorites", "Enabled").forEach { k ->
                        bar.addView(tv(c, k, 14f, if (filter == k) acc else Color.WHITE).apply {
                            background = round(if (filter == k) 0xFF2C2F4A.toInt() else 0xFF262B2F.toInt(), dp(c, 12)); setPadding(dp(c, 16), dp(c, 8), dp(c, 16), dp(c, 8))
                            setOnClickListener { filter = k; render() } }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(c, 8) })
                    }
                    bar.addView(View(c), LinearLayout.LayoutParams(0, 1, 1f))
                    bar.addView(pill(if (addOpen) "Close form" else "+ Add mod", addOpen) { addOpen = !addOpen; render() })
                    content.addView(bar)
                    if (addOpen) {
                        val nm = EditText(c).apply { hint = "Mod name"; setHintTextColor(0xFF8A9096.toInt()); setTextColor(Color.WHITE); isSingleLine = true; background = round(0xFF22272B.toInt(), dp(c, 10)); setPadding(dp(c, 12), dp(c, 8), dp(c, 12), dp(c, 8)) }
                        val cd = EditText(c).apply { hint = "Paste the mod code here"; setHintTextColor(0xFF8A9096.toInt()); setTextColor(Color.WHITE); minLines = 3; maxLines = 5; gravity = Gravity.TOP; background = round(0xFF22272B.toInt(), dp(c, 10)); setPadding(dp(c, 12), dp(c, 8), dp(c, 12), dp(c, 8)) }
                        content.addView(nm, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(c, 6) })
                        content.addView(cd, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(c, 6) })
                        content.addView(pill("Add", true) {
                            if (cd.text.isNullOrBlank()) toast(c, "Paste some code first") else {
                                val a = mods(c); a.put(JSONObject().put("n", nm.text.toString().ifBlank { "Mod ${a.length() + 1}" }).put("c", cd.text.toString()).put("on", true))
                                saveMods(c, a); addOpen = false; toast(c, "Added. Build & import it in the Moonlight app to apply."); render() } })
                    }
                    content.addView(ScrollView(c).apply { addView(body) }, LinearLayout.LayoutParams(-1, 0, 1f))
                    fillMods(c, body, p, filter, query, acc, { render() })
                }
                "HUD Editor" -> {
                    body.addView(tv(c, "Pick which of your mods show on the game screen, then drag them where you want.", 14f, MUTED).apply { setPadding(0, dp(c, 8), 0, dp(c, 10)) })
                    val arr = mods(c)
                    if (arr.length() == 0) body.addView(tv(c, "No mods yet. Add some on the Mods page.", 15f, MUTED))
                    for (i in 0 until arr.length()) {
                        val name = arr.getJSONObject(i).getString("n"); val shown = p.getBoolean("hud_show_$name", false)
                        val r = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(c, 6), 0, dp(c, 6)) }
                        r.addView(tv(c, name, 16f), LinearLayout.LayoutParams(0, -2, 1f))
                        r.addView(pill(if (shown) "On screen" else "Hidden", shown) { p.edit().putBoolean("hud_show_$name", !shown).apply(); host.refreshHud(); render() })
                        body.addView(r)
                    }
                    body.addView(pill("Edit positions", true) {
                        val any = (0 until mods(c).length()).any { val o = mods(c).getJSONObject(it); o.getBoolean("on") && p.getBoolean("hud_show_${o.getString("n")}", false) }
                        if (!any) toast(c, "Turn a mod to \"On screen\" first") else { close(); host.editHud(true) } })
                    content.addView(ScrollView(c).apply { addView(body) }, LinearLayout.LayoutParams(-1, 0, 1f))
                }
                else -> {
                    body.addView(tv(c, "Theme color", 16f, Color.WHITE, true).apply { setPadding(0, dp(c, 8), 0, dp(c, 6)) })
                    COLORS.toList().chunked(8).forEach { rowColors ->
                        val r = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, 0, dp(c, 8)) }
                        rowColors.forEach { col ->
                            r.addView(View(c).apply {
                                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(col); if (col == acc) setStroke(dp(c, 3), Color.WHITE) }
                                setOnClickListener { p.edit().putInt("accent", col).apply(); host.refreshHud(); render() } },
                                LinearLayout.LayoutParams(dp(c, 34), dp(c, 34)).apply { rightMargin = dp(c, 10) })
                        }
                        body.addView(r)
                    }
                    slider(body, "Transparency", "ov_transp", 10f)
                    slider(body, "Brightness", "ov_bright", 100f)
                    slider(body, "Background blur", "ov_blur", 0f)
                    body.addView(tv(c, "Blur needs Android 12 or newer.", 12f, MUTED))
                    val boost = p.getBoolean("fps_boost", false)
                    body.addView(tv(c, "FPS Booster", 16f, Color.WHITE, true).apply { setPadding(0, dp(c, 14), 0, dp(c, 4)) })
                    body.addView(tv(c, "Asks your phone for its highest refresh rate, steady speed and top priority for the game. It can't promise a number like 100 FPS, and it only works when Minecraft runs inside Moonlight. Takes effect next launch.", 13f, MUTED).apply { setPadding(0, 0, 0, dp(c, 8)) })
                    body.addView(pill(if (boost) "FPS Booster: On" else "FPS Booster: Off", boost) { p.edit().putBoolean("fps_boost", !boost).apply(); render() })
                    content.addView(ScrollView(c).apply { addView(body) }, LinearLayout.LayoutParams(-1, 0, 1f))
                }
            }
        }
        look(); render()
        return scrim
    }

    private fun fillMods(c: Context, body: LinearLayout, p: android.content.SharedPreferences, filter: String, query: String, acc: Int, redo: () -> Unit) {
        body.removeAllViews()
        val arr = mods(c); val favs = p.getStringSet("favs", emptySet())!!.toMutableSet()
        val shown = (0 until arr.length()).filter { i ->
            val o = arr.getJSONObject(i); val n = o.getString("n")
            (query.isBlank() || n.contains(query, true)) && when (filter) { "Favorites" -> n in favs; "Enabled" -> o.getBoolean("on"); else -> true } }
        body.addView(tv(c, "${shown.size} / ${arr.length()}", 13f, MUTED).apply { setPadding(0, 0, 0, dp(c, 6)) })
        if (arr.length() == 0) body.addView(tv(c, "No mods yet. Tap \"+ Add mod\" and paste your code.", 15f, MUTED))
        shown.chunked(4).forEach { row ->
            val r = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
            row.forEach { i ->
                val o = arr.getJSONObject(i); val n = o.getString("n"); val on = o.getBoolean("on")
                val cardV = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; background = round(CARD, dp(c, 14)); setPadding(dp(c, 12), dp(c, 12), dp(c, 12), dp(c, 12)) }
                val t = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                t.addView(tv(c, n.take(1).uppercase(), 18f, Color.WHITE, true).apply { gravity = Gravity.CENTER; background = round(TILE, dp(c, 8)) }, LinearLayout.LayoutParams(dp(c, 38), dp(c, 38)))
                t.addView(View(c), LinearLayout.LayoutParams(0, 1, 1f))
                t.addView(tv(c, if (n in favs) "*" else "+", 20f, 0xFFDDDDDD.toInt()).apply { setOnClickListener {
                    val s = p.getStringSet("favs", emptySet())!!.toMutableSet(); if (!s.add(n)) s.remove(n); p.edit().putStringSet("favs", s).apply(); redo() } })
                cardV.addView(t)
                cardV.addView(tv(c, n, 15f, Color.WHITE, true).apply { setPadding(0, dp(c, 8), 0, dp(c, 8)); maxLines = 1 })
                val b = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                b.addView(tv(c, if (on) "Enabled" else "Disabled", 13f, Color.WHITE, true).apply {
                    background = round(if (on) acc else BG, dp(c, 12)); setPadding(dp(c, 12), dp(c, 6), dp(c, 12), dp(c, 6))
                    setOnClickListener { arr.getJSONObject(i).put("on", !on); saveMods(c, arr); redo() } })
                b.addView(View(c), LinearLayout.LayoutParams(0, 1, 1f))
                b.addView(tv(c, "Delete", 12f, MUTED).apply { setOnClickListener { arr.remove(i); saveMods(c, arr); redo() } })
                cardV.addView(b)
                r.addView(cardV, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(c, 5), dp(c, 5), dp(c, 5), dp(c, 5)) })
            }
            repeat(4 - row.size) { r.addView(View(c), LinearLayout.LayoutParams(0, 1, 1f)) }
            body.addView(r)
        }
    }
}
