package com.moonlight.launcher

import android.app.Activity
import android.os.Build
import android.os.Process
import android.view.WindowManager

/**
 * "FPS Booster": asks Android for everything it offers to keep a game smooth.
 * It can only touch the game when Minecraft runs inside Moonlight. It cannot promise any FPS number.
 */
object Booster {
    fun apply(a: Activity) {
        try { // highest refresh rate the screen supports
            val best = a.windowManager.defaultDisplay.supportedModes.maxByOrNull { it.refreshRate }
            if (best != null) a.window.attributes = a.window.attributes.apply { preferredDisplayModeId = best.modeId }
        } catch (_: Throwable) {}
        try { if (Build.VERSION.SDK_INT >= 24) a.window.setSustainedPerformanceMode(true) } catch (_: Throwable) {}   // steady speed, less throttling
        try { a.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) } catch (_: Throwable) {}
        try { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY) } catch (_: Throwable) {}              // main thread first
    }
}
